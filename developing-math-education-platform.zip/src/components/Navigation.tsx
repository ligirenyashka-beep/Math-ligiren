"use client";
import Link from "next/link";
import { Sparkles, Menu, X } from "lucide-react";
import { useState } from "react";

export default function Navigation() {
  const [mobileOpen, setMobileOpen] = useState(false);

  const links = [
    { label: "Этапы", href: "/stages" },
    { label: "Теория", href: "/theory" },
    { label: "Практика", href: "/practice" },
    { label: "ОГЭ / ЕГЭ", href: "/exams" },
    { label: "Высшая математика", href: "/uni" },
  ];

  return (
    <nav className="sticky top-0 z-50 bg-cream/80 backdrop-blur-xl border-b border-parchment/60">
      <div className="max-w-6xl mx-auto px-6 md:px-10">
        <div className="flex items-center justify-between h-16 md:h-20">
          <Link href="/" className="flex items-center gap-3 group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-gold to-early-soft flex items-center justify-center shadow-md group-hover:shadow-lg transition-shadow">
              <Sparkles className="w-5 h-5 text-ink" />
            </div>
            <div className="flex flex-col">
              <span className="font-display text-xl md:text-2xl font-semibold text-ink leading-none tracking-tight">ПингЛи</span>
              <span className="text-[10px] md:text-xs text-ink-muted tracking-[0.12em] uppercase font-medium">Академия</span>
            </div>
          </Link>

          {/* Desktop links */}
          <div className="hidden md:flex items-center gap-1">
            {links.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="px-4 py-2 text-[13px] font-medium text-ink-soft hover:text-ink rounded-full hover:bg-parchment transition-colors tracking-tight"
              >
                {link.label}
              </Link>
            ))}
          </div>

          {/* Mobile toggle */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="md:hidden p-2 -mr-2 text-ink hover:bg-parchment rounded-xl transition-colors"
            aria-label="Меню"
          >
            {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <div
        className={`md:hidden overflow-hidden transition-all duration-300 ease-in-out ${
          mobileOpen ? "max-h-80 border-t border-parchment/60" : "max-h-0"
        }`}
      >
        <div className="max-w-6xl mx-auto px-6 py-4 flex flex-col gap-1">
          {links.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              onClick={() => setMobileOpen(false)}
              className="px-4 py-3 text-sm font-medium text-ink-soft hover:text-ink hover:bg-parchment rounded-xl transition-colors"
            >
              {link.label}
            </Link>
          ))}
        </div>
      </div>
    </nav>
  );
}
