import Link from "next/link";
import { ArrowLeft, GraduationCap, BookOpen, TrendingUp, Grid3x3, Dices, Waves, Award } from "lucide-react";

export default function UniPage() {
  return (
    <main className="min-h-screen bg-cream">
      <section className="max-w-6xl mx-auto px-6 md:px-10 pt-10 pb-4">
        <Link href="/" className="inline-flex items-center gap-2 text-xs font-medium text-ink-muted hover:text-ink transition-colors mb-8">
          <ArrowLeft className="w-4 h-4" /> Назад к главной
        </Link>
        <div className="max-w-2xl mb-12 md:mb-16">
          <h1 className="font-display text-[clamp(2.5rem,6vw,4.5rem)] font-semibold text-ink leading-[1.05] mb-4">Высшая математика</h1>
          <p className="text-base md:text-lg text-ink-muted leading-relaxed">Программа для абитуриентов, студентов и всех, кто хочет углубиться в математический анализ, линейную алгебру, теорию вероятностей и дифференциальные уравнения.</p>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-6 md:px-10 pb-20 md:pb-28">
        <div className="grid md:grid-cols-2 gap-4 mb-12">
          {[
            { title: "Математический анализ", subtitle: "Пределы, производные, интегралы", desc: "Пределы последовательностей, производные функций, интегралы, ряды, исследование функций.", icon: TrendingUp, color: "#3D6B6B", bg: "bg-[#E8F0F0]" },
            { title: "Линейная алгебра", subtitle: "Матрицы и векторные пространства", desc: "Матрицы, определители, системы линейных уравнений, векторные пространства, линейные операторы.", icon: Grid3x3, color: "#4D7B7B", bg: "bg-[#E8F0F0]" },
            { title: "Теория вероятностей", subtitle: "Случайные величины", desc: "События и операции, классическое определение вероятности, случайные величины, закон больших чисел.", icon: Dices, color: "#5D8B8B", bg: "bg-[#E8F0F0]" },
            { title: "Дифференциальные уравнения", subtitle: "Обыкновенные и в частных производных", desc: "ДУ первого порядка, высших порядков, системы ДУ, методы решения, ДУ в частных производных.", icon: Waves, color: "#6D9B9B", bg: "bg-[#E8F0F0]" },
            { title: "Абитуриентская подготовка", subtitle: "Математика для вузов", desc: "Программы для технических и экономических вузов, научные исследования, подготовка к олимпиадам.", icon: Award, color: "#7DABAB", bg: "bg-[#E8F0F0]" },
            { title: "Математика для студентов", subtitle: "Практика и теория", desc: "Комплексные задачи по анализу, алгебре и теории вероятностей для студентов 1-4 курсов.", icon: BookOpen, color: "#3D6B6B", bg: "bg-[#E8F0F0]" },
          ].map((topic) => (
            <Link key={topic.title} href="/stages/uni" className="group relative bg-white rounded-[2rem] p-6 md:p-8 border border-ink/5 shadow-[0_4px_20px_rgba(16,24,40,0.04)] hover:shadow-[0_8px_30px_rgba(16,24,40,0.08)] transition-all hover:-translate-y-0.5 overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 rounded-full opacity-20 blur-[40px] translate-x-6 -translate-y-8" style={{ backgroundColor: topic.color }} />
              <div className="relative">
                <div className={`w-12 h-12 rounded-2xl ${topic.bg} flex items-center justify-center mb-5`}>
                  <topic.icon className="w-6 h-6" style={{ color: topic.color }} />
                </div>
                <h2 className="font-display text-xl font-semibold text-ink mb-1">{topic.title}</h2>
                <p className="text-xs font-medium tracking-wide uppercase mb-3" style={{ color: topic.color }}>{topic.subtitle}</p>
                <p className="text-sm text-ink-muted leading-relaxed">{topic.desc}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </main>
  );
}
