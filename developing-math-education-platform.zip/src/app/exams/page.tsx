import Link from "next/link";
import { ArrowLeft, Award, GraduationCap, BookText } from "lucide-react";

export default function ExamsPage() {
  return (
    <main className="min-h-screen bg-cream">
      <section className="max-w-6xl mx-auto px-6 md:px-10 pt-10 pb-4">
        <Link href="/" className="inline-flex items-center gap-2 text-xs font-medium text-ink-muted hover:text-ink transition-colors mb-8">
          <ArrowLeft className="w-4 h-4" /> Назад к главной
        </Link>
        <div className="max-w-2xl mb-12 md:mb-16">
          <h1 className="font-display text-[clamp(2.5rem,6vw,4.5rem)] font-semibold text-ink leading-[1.05] mb-4">Подготовка к экзаменам</h1>
          <p className="text-base md:text-lg text-ink-muted leading-relaxed">ВПР, ОГЭ, ЕГЭ — с разбором типовых ошибок и стратегиями решения. Без таймеров и стресса.</p>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-6 md:px-10 pb-20 md:pb-28">
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { label: "ВПР", subtitle: "Всероссийские проверочные работы", icon: BookText, color: "#6BA8D0", bg: "bg-[#EAF4FB]", desc: "Тренировочные варианты для 1, 2, 3, 4, 5, 6, 7, 8 классов. Полное соответствие ФГОС и структуре ВПР. Разбор типовых ошибок и методические рекомендации.", grades: "1 — 8 класс", href: "/exams/vpr" },
            { label: "ОГЭ", subtitle: "Основной государственный экзамен", icon: Award, color: "#C85A5A", bg: "bg-[#FCE8E8]", desc: "Алгебра, геометрия, теория чисел, комбинаторика. Полный разбор структуры экзамена с типовыми ошибками и стратегиями решения каждого типа задания.", grades: "9 класс", href: "/exams/oge" },
            { label: "ЕГЭ", subtitle: "Единый государственный экзамен", icon: GraduationCap, color: "#7B5AA6", bg: "bg-[#F0E8F8]", desc: "Профильная и базовая математика. Разбор всех вариантов, стратегии решения сложных заданий, подготовка к олимпиадным элементам в экзамене.", grades: "10 — 11 класс", href: "/exams/ege" },
          ].map((exam) => (
            <Link key={exam.label} href={exam.href} className="group relative bg-white rounded-[2.5rem] p-8 md:p-10 border border-ink/5 shadow-[0_4px_24px_rgba(16,24,40,0.04)] hover:shadow-[0_8px_32px_rgba(16,24,40,0.08)] transition-all hover:-translate-y-1 overflow-hidden">
              <div className="absolute top-0 right-0 w-48 h-48 rounded-full opacity-15 blur-[60px] translate-x-10 -translate-y-12" style={{ backgroundColor: exam.color }} />
              <div className="relative">
                <div className={`w-14 h-14 rounded-2xl ${exam.bg} flex items-center justify-center mb-6`}>
                  <exam.icon className="w-7 h-7" style={{ color: exam.color }} />
                </div>
                <h2 className="font-display text-3xl font-semibold text-ink mb-1">{exam.label}</h2>
                <p className="text-sm text-ink-muted mb-4">{exam.subtitle}</p>
                <p className="text-sm text-ink-soft leading-relaxed mb-6">{exam.desc}</p>
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-parchment text-xs font-medium text-ink-soft">
                  {exam.grades}
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </main>
  );
}
