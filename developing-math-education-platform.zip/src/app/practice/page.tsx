export const dynamic = "force-dynamic";
import Link from "next/link";
import { ArrowLeft, CheckCircle2, Lightbulb, Eye, Volume2 } from "lucide-react";
import { db } from "@/db";
import { practices } from "@/db/schema";
import { desc, sql } from "drizzle-orm";

export default async function PracticePage() {
  const allPractices = await db.select().from(practices).limit(30);

  // Group by age
  const groups: Record<string, typeof allPractices> = {};
  for (const p of allPractices) {
    const key = p.ageAppropriate || "other";
    if (!groups[key]) groups[key] = [];
    groups[key].push(p);
  }

  return (
    <main className="min-h-screen bg-cream">
      <section className="max-w-6xl mx-auto px-6 md:px-10 pt-10 pb-4">
        <Link href="/" className="inline-flex items-center gap-2 text-xs font-medium text-ink-muted hover:text-ink transition-colors mb-8">
          <ArrowLeft className="w-4 h-4" /> Назад к главной
        </Link>
        <div className="max-w-2xl mb-12 md:mb-16">
          <h1 className="font-display text-[clamp(2.5rem,6vw,4.5rem)] font-semibold text-ink leading-[1.05] mb-4">Практика</h1>
          <p className="text-base md:text-lg text-ink-muted leading-relaxed">Без таймеров. Без давления. Каждое задание можно решать столько, сколько нужно. Для детей 4-7 лет — визуальные и аудио-форматы с минимальным текстом.</p>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-6 md:px-10 pb-20 md:pb-28">
        <div className="flex flex-wrap gap-2 mb-8">
          {Object.keys(groups).map((key) => (
            <a key={key} href={`#group-${key}`} className="px-4 py-1.5 rounded-full bg-ink/5 text-xs font-medium text-ink hover:bg-ink/10 transition-colors border border-ink/5">
              {key === "4-7" ? "4 — 7 лет" : key === "8-11" ? "8 — 11 лет" : key === "12-15" ? "12 — 15 лет" : key === "16-18" ? "16 — 18 лет" : key}
            </a>
          ))}
        </div>

        <div className="flex flex-col gap-12 md:gap-16">
          {Object.entries(groups).map(([ageKey, practicesList]) => (
            <div key={ageKey} id={`group-${ageKey}`} className="scroll-mt-28">
              <div className="flex items-center gap-3 mb-6">
                <h2 className="font-display text-xl md:text-2xl font-semibold text-ink">{ageKey === "4-7" ? "4 — 7 лет" : ageKey === "8-11" ? "8 — 11 лет" : ageKey === "12-15" ? "12 — 15 лет" : ageKey === "16-18" ? "16 — 18 лет" : ageKey}</h2>
                <div className="flex-1 h-px bg-ink/5" />
                <span className="text-xs text-ink-muted">{practicesList.length} заданий</span>
              </div>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {practicesList.map((practice) => (
                  <Link key={practice.id} href={`/practice/${practice.slug}`} className="group relative bg-white rounded-3xl p-6 border border-ink/5 shadow-[0_2px_12px_rgba(16,24,40,0.04)] hover:shadow-[0_8px_24px_rgba(16,24,40,0.08)] transition-all hover:-translate-y-0.5">
                    <div className="flex items-start justify-between mb-4">
                      <span className="text-[10px] font-semibold tracking-wider uppercase px-2.5 py-1 rounded-full bg-parchment text-ink-muted">
                        Уровень {practice.difficulty}
                      </span>
                      <div className="flex gap-1">
                        {practice.isVisual && <span aria-label="Визуальное"><Eye className="w-3.5 h-3.5 text-ink-muted" /></span>}
                        {practice.isAudio && <span aria-label="Аудио"><Volume2 className="w-3.5 h-3.5 text-ink-muted" /></span>}
                      </div>
                    </div>
                    <h3 className="font-display text-lg font-semibold text-ink mb-2 leading-snug">{practice.title}</h3>
                    <p className="text-sm text-ink-muted leading-relaxed mb-4 line-clamp-3">{practice.body}</p>
                    <div className="flex items-center gap-3 pt-4 border-t border-ink/5">
                      <span className="text-[11px] text-ink-muted">Без таймера</span>
                      <span className="text-[11px] px-2 py-0.5 rounded-full bg-parchment text-ink-soft font-medium">Ответ: {practice.answer}</span>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
