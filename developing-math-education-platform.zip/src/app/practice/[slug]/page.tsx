import { notFound } from "next/navigation";
import { db } from "@/db";
import { practices } from "@/db/schema";
import { eq } from "drizzle-orm";
import Link from "next/link";
import { ArrowLeft, Lightbulb, Sparkles, Eye, Volume2, CheckCircle2 } from "lucide-react";

export default async function PracticeDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const result = await db.select().from(practices).where(eq(practices.slug, slug)).limit(1);
  const practice = result[0];

  if (!practice) return notFound();

  const isYoung = practice.ageAppropriate?.includes("4-7");

  return (
    <main className="min-h-screen bg-cream">
      <section className="max-w-3xl mx-auto px-6 md:px-10 pt-10 pb-16 md:pb-24">
        <Link href="/practice" className="inline-flex items-center gap-2 text-xs font-medium text-ink-muted hover:text-ink transition-colors mb-8">
          <ArrowLeft className="w-4 h-4" /> Назад к практике
        </Link>

        <div className="bg-white rounded-[2.5rem] p-8 md:p-14 shadow-[0_4px_40px_rgba(16,24,40,0.05)] border border-ink/5 relative overflow-hidden">
          {/* Visual indicator for young ages */}
          {isYoung && (
            <div className="absolute top-0 right-0 w-40 h-40 bg-early-soft/40 rounded-full blur-[60px] translate-x-8 -translate-y-12" />
          )}

          <div className="relative">
            <div className="flex items-center gap-2 mb-6">
              <span className="text-[10px] font-semibold tracking-wider uppercase px-2.5 py-1 rounded-full bg-parchment text-ink-muted">
                Уровень {practice.difficulty}
              </span>
              <span className="text-[10px] font-semibold tracking-wider uppercase px-2.5 py-1 rounded-full bg-parchment text-ink-muted">
                Без таймера
              </span>
              {isYoung && (
                <span className="text-[10px] font-semibold tracking-wider uppercase px-2.5 py-1 rounded-full bg-early-soft text-ink-soft">
                  Для детей 4-7 лет
                </span>
              )}
              <div className="flex gap-2 ml-auto">
                {practice.isVisual && <span aria-label="Визуальное" className="text-[10px] px-2 py-0.5 rounded-full bg-parchment text-ink-muted flex items-center gap-1"><Eye className="w-3 h-3" /> Визуально</span>}
                {practice.isAudio && <span aria-label="Аудио" className="text-[10px] px-2 py-0.5 rounded-full bg-parchment text-ink-muted flex items-center gap-1"><Volume2 className="w-3 h-3" /> Аудио</span>}
              </div>
            </div>

            <h1 className="font-display text-3xl md:text-4xl font-semibold text-ink mb-6 leading-tight">{practice.title}</h1>

            <div className="prose prose-lg max-w-none mb-8">
              <p className="text-base md:text-xl text-ink-soft leading-relaxed">{practice.body}</p>
            </div>

            {/* Age-appropriate visual block for 4-7 */}
            {isYoung && (
              <div className="bg-gradient-to-br from-early-soft/40 to-parchment rounded-2xl p-6 md:p-8 mb-8 border border-early/10">
                <div className="flex items-center gap-2 mb-4">
                  <Sparkles className="w-5 h-5 text-early" />
                  <h3 className="font-display text-lg font-semibold text-ink">Для самых маленьких</h3>
                </div>
                <p className="text-sm text-ink-muted leading-relaxed mb-4">
                  Это задание специально сделано для детей, которые ещё плохо читают текст. Здесь используются только картинки, звуки и крупные элементы для нажатия. Родитель может читать подсказки вслух.
                </p>
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-white rounded-xl p-4 text-center border border-ink/5 shadow-sm">
                    <div className="w-8 h-8 mx-auto mb-2 rounded-full bg-early-soft flex items-center justify-center">
                      <Eye className="w-4 h-4 text-early" />
                    </div>
                    <p className="text-[11px] font-medium text-ink">Картинки</p>
                  </div>
                  <div className="bg-white rounded-xl p-4 text-center border border-ink/5 shadow-sm">
                    <div className="w-8 h-8 mx-auto mb-2 rounded-full bg-early-soft flex items-center justify-center">
                      <Volume2 className="w-4 h-4 text-early" />
                    </div>
                    <p className="text-[11px] font-medium text-ink">Голос</p>
                  </div>
                  <div className="bg-white rounded-xl p-4 text-center border border-ink/5 shadow-sm">
                    <div className="w-8 h-8 mx-auto mb-2 rounded-full bg-early-soft flex items-center justify-center">
                      <Sparkles className="w-4 h-4 text-early" />
                    </div>
                    <p className="text-[11px] font-medium text-ink">Без текста</p>
                  </div>
                </div>
              </div>
            )}

            {/* Hint */}
            <div className="bg-parchment rounded-2xl p-5 md:p-6 mb-8 border border-ink/5">
              <div className="flex items-center gap-2 mb-3">
                <Lightbulb className="w-4 h-4 text-gold" />
                <h3 className="font-display text-base font-semibold text-ink">Подсказка</h3>
              </div>
              <p className="text-sm text-ink-muted leading-relaxed">{practice.hint || "Попробуй разбить задачу на части и решить каждую по очереди."}</p>
            </div>

            {/* Answer */}
            <div className="bg-gradient-to-br from-ink to-ink-soft rounded-2xl p-6 md:p-8 text-cream shadow-xl shadow-ink/20">
              <div className="flex items-center gap-2 mb-3">
                <CheckCircle2 className="w-5 h-5 text-gold-soft" />
                <h3 className="font-display text-lg font-semibold">Ответ</h3>
              </div>
              <p className="text-2xl md:text-3xl font-display font-light">{practice.answer}</p>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
