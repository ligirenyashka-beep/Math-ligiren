import Link from "next/link";
import { ArrowLeft, ArrowRight, Sparkles, Compass, Mountain, Crown, BookOpen, Hash, Shapes, Lightbulb, Clock, Calculator, Triangle, BookText, Grid3x3, Brain, FunctionSquare, CircleDot, Dices, TrendingUp, Waves, Award } from "lucide-react";

export default function StagesPage() {
  const stages = [
    {
      code: "early",
      title: "4 — 7 лет",
      subtitle: "Начало пути",
      color: "#F0A060",
      bg: "bg-[#FEF5E8]",
      border: "border-[#F0A060]/20",
      icon: Sparkles,
      desc: "Математика через игру. Без текста, с аудио-подсказками, визуальными образами и движением.",
      macroSkills: [
        { title: "Число и счёт", subtitle: "От образа к цифре", icon: Hash, desc: "Счёт до 20 через картинки, пальчики и предметы. Без текстовой нагрузки." },
        { title: "Форма и пространство", subtitle: "Геометрия через игру", icon: Shapes, desc: "Круг, квадрат, треугольник, больше-меньше, построение из палочек." },
        { title: "Логика и закономерности", subtitle: "Найди правило", icon: Lightbulb, desc: "Продолжи ряд, найди пару, что лишнее. Развитие логического мышления." },
        { title: "Математика в жизни", subtitle: "Деньги, время, измерения", icon: Clock, desc: "Сколько времени? Какой предмет тяжелее? Сколько стоит игрушка?" },
      ],
    },
    {
      code: "primary",
      title: "8 — 11 лет",
      subtitle: "Фундамент",
      color: "#6BA8D0",
      bg: "bg-[#EAF4FB]",
      border: "border-[#6BA8D0]/20",
      icon: Compass,
      desc: "Плавный переход от образного к абстрактному мышлению. Основы арифметики и геометрии.",
      macroSkills: [
        { title: "Арифметика", subtitle: "Числа и действия", icon: Calculator, desc: "Натуральные числа, дроби, десятичные дроби, действия с ними." },
        { title: "Геометрия", subtitle: "Плоскость и фигуры", icon: Triangle, desc: "Прямые, углы, треугольники, четырёхугольники, окружность." },
        { title: "Текстовые задачи", subtitle: "Чтение и решение", icon: BookText, desc: "Движение, работа, проценты, пропорции, комбинированные задачи." },
        { title: "Комбинаторика", subtitle: "Перебор и подсчёт", icon: Grid3x3, desc: "Правило суммы, правило произведения, перестановки, сочетания." },
        { title: "Логика", subtitle: "Доказательства и рассуждения", icon: Brain, desc: "Истинность высказываний, доказательство, метод от противного." },
      ],
    },
    {
      code: "middle",
      title: "12 — 15 лет",
      subtitle: "Углубление",
      color: "#7B5AA6",
      bg: "bg-[#F0E8F8]",
      border: "border-[#7B5AA6]/20",
      icon: Mountain,
      desc: "Алгебра, геометрия, комбинаторика и начала анализа. Подготовка к ОГЭ и олимпиадам.",
      macroSkills: [
        { title: "Алгебра", subtitle: "Уравнения и функции", icon: FunctionSquare, desc: "Линейные и квадратные уравнения, системы, неравенства, функции." },
        { title: "Геометрия", subtitle: "Треугольники и окружности", icon: CircleDot, desc: "Треугольники, окружности, площадь, теорема Пифагора, тригонометрия." },
        { title: "Комбинаторика и вероятность", subtitle: "Олимпиадные задачи", icon: Dices, desc: "Перестановки, сочетания, вероятность, условная вероятность." },
        { title: "Теория чисел", subtitle: "Делимость, НОД, НОК", icon: Hash, desc: "Простые числа, делимость, НОД, НОК, конгруэнции." },
        { title: "Логика и доказательства", subtitle: "Методы решения", icon: Lightbulb, desc: "Прямое доказательство, от противного, математическая индукция." },
        { title: "Подготовка к ОГЭ", subtitle: "Структура экзамена", icon: Award, desc: "Алгебра, геометрия, типовые ошибки, стратегия экзамена." },
      ],
    },
    {
      code: "high",
      title: "16 — 18 лет",
      subtitle: "Мастерство",
      color: "#C85A5A",
      bg: "bg-[#FCE8E8]",
      border: "border-[#C85A5A]/20",
      icon: Crown,
      desc: "ЕГЭ, высшая математика, теория чисел, аналитическая геометрия. Подготовка к вузам.",
      macroSkills: [
        { title: "Алгебра и анализ", subtitle: "Производные и интегралы", icon: TrendingUp, desc: "Пределы, производные, интегралы, экстремумы, исследование функций." },
        { title: "Аналитическая геометрия", subtitle: "Плоскость и пространство", icon: Compass, desc: "Прямая, окружность, эллипс, плоскость в пространстве, поверхности." },
        { title: "Комбинаторика", subtitle: "Перестановки, сочетания", icon: Grid3x3, desc: "Перестановки с повторениями, сочетания с повторениями, биномиальная теорема." },
        { title: "Теория чисел", subtitle: "Конгруэнции, теоремы", icon: Hash, desc: "Теорема Вильсона, малая теорема Ферма, теорема Эйлера, китайская теорема об остатках." },
        { title: "Подготовка к ЕГЭ", subtitle: "Все профили", icon: Award, desc: "Профильная математика, базовая математика, разбор вариантов, типовые ошибки." },
        { title: "Олимпиадная математика", subtitle: "Сложные задачи", icon: Crown, desc: "Международные, всероссийские, региональные олимпиады. Глубокая теория и практика." },
      ],
    },
    {
      code: "uni",
      title: "18+ лет",
      subtitle: "Высшая математика",
      color: "#3D6B6B",
      bg: "bg-[#E8F0F0]",
      border: "border-[#3D6B6B]/20",
      icon: BookOpen,
      desc: "Математический анализ, линейная алгебра, теория вероятностей, дифференциальные уравнения.",
      macroSkills: [
        { title: "Математический анализ", subtitle: "Пределы, производные, интегралы", icon: TrendingUp, desc: "Пределы последовательностей, производные, интегралы, ряды." },
        { title: "Линейная алгебра", subtitle: "Матрицы и векторные пространства", icon: Grid3x3, desc: "Матрицы, определители, системы уравнений, векторные пространства, операторы." },
        { title: "Теория вероятностей", subtitle: "Случайные величины", icon: Dices, desc: "События, классическое определение, случайные величины, закон больших чисел." },
        { title: "Дифференциальные уравнения", subtitle: "Обыкновенные и в частных производных", icon: Waves, desc: "ДУ первого порядка, высших порядков, системы ДУ, методы решения." },
        { title: "Абитуриентская подготовка", subtitle: "Математика для вузов", icon: Award, desc: "Технические вузы, экономические вузы, научные исследования, олимпиады." },
      ],
    },
  ];

  return (
    <main className="min-h-screen bg-cream">
      <section className="max-w-6xl mx-auto px-6 md:px-10 pt-10 pb-4">
        <Link href="/" className="inline-flex items-center gap-2 text-xs font-medium text-ink-muted hover:text-ink transition-colors mb-8">
          <ArrowLeft className="w-4 h-4" /> Назад к главной
        </Link>
        <div className="max-w-2xl">
          <h1 className="font-display text-[clamp(2.5rem,6vw,4.5rem)] font-semibold text-ink leading-[1.05] mb-4">Этапы обучения</h1>
          <p className="text-base md:text-lg text-ink-muted leading-relaxed">Пять макро-этапов от дошкольника до студента. Каждый этап содержит макронавыки, микронавыки, теорию и практики без таймеров.</p>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-6 md:px-10 pb-24">
        <div className="flex flex-col gap-20 md:gap-28">
          {stages.map((stage) => (
            <article key={stage.code} className={`relative rounded-[2.5rem] overflow-hidden bg-gradient-to-br ${stage.bg} border ${stage.border} p-8 md:p-12 shadow-[0_4px_30px_rgba(16,24,40,0.04)]`}>
              <div className="absolute top-0 right-0 w-64 h-64 rounded-full opacity-20 blur-[80px]" style={{ backgroundColor: stage.color }} />
              <div className="relative">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: stage.color + "15" }}>
                    <stage.icon className="w-5 h-5" style={{ color: stage.color }} />
                  </div>
                  <div>
                    <h2 className="font-display text-2xl md:text-3xl font-semibold text-ink">{stage.title} <span className="text-ink-muted font-normal">— {stage.subtitle}</span></h2>
                  </div>
                </div>
                <p className="text-sm md:text-base text-ink-muted leading-relaxed max-w-3xl mb-8">{stage.desc}</p>

                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {stage.macroSkills.map((skill) => (
                    <Link key={skill.title} href={`/stages/${stage.code}`} className="group block bg-white rounded-2xl p-5 border border-ink/5 shadow-sm hover:shadow-md transition-all hover:-translate-y-0.5">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ backgroundColor: stage.color + "15" }}>
                          <skill.icon className="w-4 h-4" style={{ color: stage.color }} />
                        </div>
                        <h3 className="font-display text-lg font-semibold text-ink leading-tight">{skill.title}</h3>
                      </div>
                      <p className="text-xs text-ink-muted mb-2">{skill.subtitle}</p>
                      <p className="text-xs text-ink-muted leading-relaxed">{skill.desc}</p>
                      <div className="mt-3 flex items-center gap-1 text-[11px] font-medium text-ink-soft group-hover:text-ink transition-colors">
                        Перейти <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
}
