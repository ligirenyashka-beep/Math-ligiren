import Link from "next/link";
import { ArrowLeft, Sparkles, Compass, Mountain, Crown, BookOpen, Hash, Shapes, Lightbulb, Clock, Calculator, Triangle, BookText, Grid3x3, Brain, FunctionSquare, CircleDot, Dices, TrendingUp, Waves, Award } from "lucide-react";
import { notFound } from "next/navigation";

const stageData: Record<string, { title: string; subtitle: string; ageRange: string; color: string; bg: string; icon: any; desc: string; macroSkills: { title: string; subtitle: string; icon: any; desc: string }[] }> = {
  early: {
    title: "4 — 7 лет", subtitle: "Начало пути", ageRange: "4 — 7 лет", color: "#F0A060", bg: "from-[#FEF5E8] to-cream", icon: Sparkles,
    desc: "Математика через игру. Без текста, с аудио-подсказками, визуальными образами и движением. Все задания максимально доступны для возраста, учитывая, что дети 4-7 лет плохо читают текст.",
    macroSkills: [
      { title: "Число и счёт", subtitle: "От образа к цифре", icon: Hash, desc: "Счёт до 20 через картинки, пальчики и предметы. Без текстовой нагрузки." },
      { title: "Форма и пространство", subtitle: "Геометрия через игру", icon: Shapes, desc: "Круг, квадрат, треугольник, больше-меньше, построение из палочек." },
      { title: "Логика и закономерности", subtitle: "Найди правило", icon: Lightbulb, desc: "Продолжи ряд, найди пару, что лишнее. Развитие логического мышления." },
      { title: "Математика в жизни", subtitle: "Деньги, время, измерения", icon: Clock, desc: "Сколько времени? Какой предмет тяжелее? Сколько стоит игрушка?" },
    ],
  },
  primary: {
    title: "8 — 11 лет", subtitle: "Фундамент", ageRange: "8 — 11 лет", color: "#6BA8D0", bg: "from-[#EAF4FB] to-cream", icon: Compass,
    desc: "Плавный переход от образного к абстрактному мышлению. Основы арифметики и геометрии с постепенным увеличением текстовой нагрузки.",
    macroSkills: [
      { title: "Арифметика", subtitle: "Числа и действия", icon: Calculator, desc: "Натуральные числа, дроби, десятичные дроби, действия с ними." },
      { title: "Геометрия", subtitle: "Плоскость и фигуры", icon: Triangle, desc: "Прямые, углы, треугольники, четырёхугольники, окружность." },
      { title: "Текстовые задачи", subtitle: "Чтение и решение", icon: BookText, desc: "Движение, работа, проценты, пропорции, комбинированные задачи." },
      { title: "Комбинаторика", subtitle: "Перебор и подсчёт", icon: Grid3x3, desc: "Правило суммы, правило произведения, перестановки, сочетания." },
      { title: "Логика", subtitle: "Доказательства и рассуждения", icon: Brain, desc: "Истинность высказываний, доказательство, метод от противного." },
    ],
  },
  middle: {
    title: "12 — 15 лет", subtitle: "Углубление", ageRange: "12 — 15 лет", color: "#7B5AA6", bg: "from-[#F0E8F8] to-cream", icon: Mountain,
    desc: "Алгебра, геометрия, комбинаторика и начала анализа. Полная подготовка к ОГЭ и олимпиадам с глубоким пониманием теории.",
    macroSkills: [
      { title: "Алгебра", subtitle: "Уравнения и функции", icon: FunctionSquare, desc: "Линейные и квадратные уравнения, системы, неравенства, функции." },
      { title: "Геометрия", subtitle: "Треугольники и окружности", icon: CircleDot, desc: "Треугольники, окружности, площадь, теорема Пифагора, тригонометрия." },
      { title: "Комбинаторика и вероятность", subtitle: "Олимпиадные задачи", icon: Dices, desc: "Перестановки, сочетания, вероятность, условная вероятность." },
      { title: "Теория чисел", subtitle: "Делимость, НОД, НОК", icon: Hash, desc: "Простые числа, делимость, НОД, НОК, конгруэнции." },
      { title: "Логика и доказательства", subtitle: "Методы решения", icon: Lightbulb, desc: "Прямое доказательство, от противного, математическая индукция." },
      { title: "Подготовка к ОГЭ", subtitle: "Структура экзамена", icon: Award, desc: "Алгебра, геометрия, типовые ошибки, стратегия экзамена." },
    ],
  },
  high: {
    title: "16 — 18 лет", subtitle: "Мастерство", ageRange: "16 — 18 лет", color: "#C85A5A", bg: "from-[#FCE8E8] to-cream", icon: Crown,
    desc: "ЕГЭ, высшая математика, теория чисел, аналитическая геометрия. Подготовка к вузам с глубоким пониманием и уверенностью.",
    macroSkills: [
      { title: "Алгебра и анализ", subtitle: "Производные и интегралы", icon: TrendingUp, desc: "Пределы, производные, интегралы, экстремумы, исследование функций." },
      { title: "Аналитическая геометрия", subtitle: "Плоскость и пространство", icon: Compass, desc: "Прямая, окружность, эллипс, плоскость в пространстве, поверхности." },
      { title: "Комбинаторика", subtitle: "Перестановки, сочетания", icon: Grid3x3, desc: "Перестановки с повторениями, сочетания с повторениями, биномиальная теорема." },
      { title: "Теория чисел", subtitle: "Конгруэнции, теоремы", icon: Hash, desc: "Теорема Вильсона, малая теорема Ферма, теорема Эйлера, китайская теорема об остатках." },
      { title: "Подготовка к ЕГЭ", subtitle: "Все профили", icon: Award, desc: "Профильная математика, базовая математика, разбор вариантов, типовые ошибки." },
      { title: "Олимпиадная математика", subtitle: "Сложные задачи", icon: Crown, desc: "Международные, всероссийские, региональные олимпиады. Глубокая теория и практика." },
    ],
  },
  uni: {
    title: "18+ лет", subtitle: "Высшая математика", ageRange: "18+ лет", color: "#3D6B6B", bg: "from-[#E8F0F0] to-cream", icon: BookOpen,
    desc: "Математический анализ, линейная алгебра, теория вероятностей, дифференциальные уравнения. Программа для абитуриентов и студентов.",
    macroSkills: [
      { title: "Математический анализ", subtitle: "Пределы, производные, интегралы", icon: TrendingUp, desc: "Пределы последовательностей, производные, интегралы, ряды." },
      { title: "Линейная алгебра", subtitle: "Матрицы и векторные пространства", icon: Grid3x3, desc: "Матрицы, определители, системы уравнений, векторные пространства, операторы." },
      { title: "Теория вероятностей", subtitle: "Случайные величины", icon: Dices, desc: "События, классическое определение, случайные величины, закон больших чисел." },
      { title: "Дифференциальные уравнения", subtitle: "Обыкновенные и в частных производных", icon: Waves, desc: "ДУ первого порядка, высших порядков, системы ДУ, методы решения." },
      { title: "Абитуриентская подготовка", subtitle: "Математика для вузов", icon: Award, desc: "Технические вузы, экономические вузы, научные исследования, олимпиады." },
    ],
  },
};

export default async function StagePage({ params }: { params: Promise<{ stage: string }> }) {
  const { stage } = await params;
  const data = stageData[stage];
  if (!data) return notFound();

  return (
    <main className="min-h-screen bg-cream">
      <section className={`max-w-6xl mx-auto px-6 md:px-10 pt-10 pb-24 bg-gradient-to-b ${data.bg} rounded-b-[3rem]`}>
        <Link href="/stages" className="inline-flex items-center gap-2 text-xs font-medium text-ink-muted hover:text-ink transition-colors mb-8">
          <ArrowLeft className="w-4 h-4" /> Назад к этапам
        </Link>
        <div className="max-w-2xl">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center shadow-sm" style={{ backgroundColor: data.color + "15" }}>
              <data.icon className="w-6 h-6" style={{ color: data.color }} />
            </div>
            <span className="text-xs font-semibold tracking-wider uppercase px-3 py-1 rounded-full" style={{ backgroundColor: data.color + "15", color: data.color }}>{data.ageRange}</span>
          </div>
          <h1 className="font-display text-[clamp(2.5rem,6vw,4.5rem)] font-semibold text-ink leading-[1.05] mb-4">{data.title} <span className="font-normal text-ink-muted">— {data.subtitle}</span></h1>
          <p className="text-base md:text-lg text-ink-muted leading-relaxed">{data.desc}</p>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-6 md:px-10 -mt-12 pb-20 md:pb-28">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {data.macroSkills.map((skill) => (
            <Link key={skill.title} href="#" className="group block bg-white rounded-3xl p-6 md:p-8 border border-ink/5 shadow-[0_4px_20px_rgba(16,24,40,0.05)] hover:shadow-[0_8px_30px_rgba(16,24,40,0.1)] transition-all hover:-translate-y-1">
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center mb-5 shadow-sm" style={{ backgroundColor: data.color + "15" }}>
                <skill.icon className="w-6 h-6" style={{ color: data.color }} />
              </div>
              <h2 className="font-display text-xl font-semibold text-ink mb-1">{skill.title}</h2>
              <p className="text-xs font-medium tracking-wide uppercase mb-3" style={{ color: data.color }}>{skill.subtitle}</p>
              <p className="text-sm text-ink-muted leading-relaxed">{skill.desc}</p>
              <div className="mt-5 pt-4 border-t border-ink/5 flex items-center justify-between">
                <span className="text-[11px] text-ink-muted">Микронавыки и практика</span>
                <span className="text-[11px] font-medium text-ink-soft group-hover:text-ink transition-colors">Перейти →</span>
              </div>
            </Link>
          ))}
        </div>

        <div className="mt-12 md:mt-16 bg-gradient-to-br from-parchment to-cream rounded-[2rem] p-8 md:p-10 border border-ink/5">
          <h3 className="font-display text-xl md:text-2xl font-semibold text-ink mb-4">Особенности этого этапа</h3>
          <ul className="space-y-3 text-sm text-ink-muted">
            <li className="flex items-start gap-3">
              <span className="w-1.5 h-1.5 rounded-full mt-1.5 shrink-0" style={{ backgroundColor: data.color }} />
              <span>Без таймеров в практиках. Каждый ребёнок работает в своём темпе.</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="w-1.5 h-1.5 rounded-full mt-1.5 shrink-0" style={{ backgroundColor: data.color }} />
              <span>Возрастная адаптация заданий: для 4-7 лет — визуальные и аудио-форматы с минимальным текстом.</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="w-1.5 h-1.5 rounded-full mt-1.5 shrink-0" style={{ backgroundColor: data.color }} />
              <span>Единая система макронавыков и микронавыков с визуальной картой прогресса.</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="w-1.5 h-1.5 rounded-full mt-1.5 shrink-0" style={{ backgroundColor: data.color }} />
              <span>Подготовка к ВПР, ОГЭ и ЕГЭ в соответствии с федеральными образовательными стандартами.</span>
            </li>
          </ul>
        </div>
      </section>
    </main>
  );
}
