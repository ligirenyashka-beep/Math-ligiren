import Link from "next/link";
import { ArrowLeft, BookOpen, ChevronRight, GraduationCap } from "lucide-react";

export default function TheoryPage() {
  const grades = [
    { label: "Дошкольники (4-7)", subjects: ["Число и счёт", "Форма и пространство", "Логика", "Математика в жизни"], href: "/theory/early" },
    { label: "1 класс", subjects: ["Нумерация до 20", "Сложение и вычитание", "Геометрические фигуры", "Измерения"], href: "/theory/grade-1" },
    { label: "2 класс", subjects: ["Нумерация до 100", "Таблица умножения", "Периметр и площадь", "Текстовые задачи"], href: "/theory/grade-2" },
    { label: "3 класс", subjects: ["Дроби", "Умножение в столбик", "Геометрия", "Комбинаторика"], href: "/theory/grade-3" },
    { label: "4 класс", subjects: ["Десятичные дроби", "Проценты", "Объём", "Олимпиадная подготовка"], href: "/theory/grade-4" },
    { label: "5 класс", subjects: ["Натуральные числа", "Дроби", "Проценты", "Геометрия", "Логика"], href: "/theory/grade-5" },
    { label: "6 класс", subjects: ["Делимость", "НОД и НОК", "Дроби", "Пропорции"], href: "/theory/grade-6" },
    { label: "7 класс", subjects: ["Алгебраические выражения", "Функции", "Треугольники", "Окружность"], href: "/theory/grade-7" },
    { label: "8 класс", subjects: ["Квадратные уравнения", "Неравенства", "Площадь и объём", "Вероятность"], href: "/theory/grade-8" },
    { label: "9 класс", subjects: ["Алгебра ОГЭ", "Геометрия ОГЭ", "Комбинаторика", "Теория чисел"], href: "/theory/grade-9" },
    { label: "10 класс", subjects: ["Производная", "Интеграл", "Аналитическая геометрия", "Тригонометрия"], href: "/theory/grade-10" },
    { label: "11 класс", subjects: ["ЕГЭ: алгебра", "ЕГЭ: геометрия", "ЕГЭ: теория чисел", "Олимпиада"], href: "/theory/grade-11" },
  ];

  const university = [
    { label: "Математический анализ", desc: "Пределы, производные, интегралы, ряды", href: "/theory/uni/analysis" },
    { label: "Линейная алгебра", desc: "Матрицы, векторные пространства, операторы", href: "/theory/uni/algebra" },
    { label: "Теория вероятностей", desc: "События, случайные величины, распределения", href: "/theory/uni/probability" },
    { label: "Дифференциальные уравнения", desc: "Обыкновенные, в частных производных", href: "/theory/uni/de" },
  ];

  return (
    <main className="min-h-screen bg-cream">
      <section className="max-w-6xl mx-auto px-6 md:px-10 pt-10 pb-4">
        <Link href="/" className="inline-flex items-center gap-2 text-xs font-medium text-ink-muted hover:text-ink transition-colors mb-8">
          <ArrowLeft className="w-4 h-4" /> Назад к главной
        </Link>
        <div className="max-w-2xl mb-12 md:mb-16">
          <h1 className="font-display text-[clamp(2.5rem,6vw,4.5rem)] font-semibold text-ink leading-[1.05] mb-4">Теория</h1>
          <p className="text-base md:text-lg text-ink-muted leading-relaxed">Структура по классам и возрастам в соответствии с ФГОС РФ, а также с расширенными разделами для олимпиадной и высшей математики.</p>
        </div>
      </section>

      {/* School theory */}
      <section className="max-w-6xl mx-auto px-6 md:px-10 mb-16 md:mb-28">
        <h2 className="font-display text-2xl md:text-3xl font-semibold text-ink mb-2">Школьная программа</h2>
        <p className="text-sm text-ink-muted mb-8">По классам в соответствии с ФГОС начального и основного общего образования</p>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {grades.map((g) => (
            <Link key={g.label} href={g.href} className="group flex items-center gap-3 p-5 rounded-2xl bg-white border border-ink/5 hover:border-gold/30 shadow-sm hover:shadow-md transition-all hover:-translate-y-0.5">
              <div className="w-10 h-10 rounded-xl bg-parchment flex items-center justify-center shrink-0">
                <BookOpen className="w-4 h-4 text-ink-soft" />
              </div>
              <div className="min-w-0">
                <h3 className="font-display text-base font-semibold text-ink truncate">{g.label}</h3>
                <div className="flex flex-wrap gap-1 mt-1.5">
                  {g.subjects.slice(0, 2).map((s) => (
                    <span key={s} className="text-[10px] px-2 py-0.5 rounded-full bg-parchment text-ink-muted">{s}</span>
                  ))}
                  {g.subjects.length > 2 && <span className="text-[10px] px-2 py-0.5 rounded-full bg-parchment text-ink-muted">+{g.subjects.length - 2}</span>}
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-ink-muted opacity-0 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all ml-auto shrink-0" />
            </Link>
          ))}
        </div>
      </section>

      {/* University theory */}
      <section className="max-w-6xl mx-auto px-6 md:px-10 mb-16 md:mb-28">
        <h2 className="font-display text-2xl md:text-3xl font-semibold text-ink mb-2">Высшая математика</h2>
        <p className="text-sm text-ink-muted mb-8">Для абитуриентов, студентов и всех, кто хочет углубиться</p>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {university.map((g) => (
            <Link key={g.label} href={g.href} className="group flex flex-col p-5 rounded-2xl bg-gradient-to-br from-parchment to-cream border border-ink/5 hover:border-gold/30 shadow-sm hover:shadow-md transition-all hover:-translate-y-0.5">
              <div className="w-10 h-10 rounded-xl bg-teal-soft flex items-center justify-center mb-4">
                <GraduationCap className="w-4 h-4 text-teal" />
              </div>
              <h3 className="font-display text-base font-semibold text-ink mb-1">{g.label}</h3>
              <p className="text-xs text-ink-muted leading-relaxed">{g.desc}</p>
              <div className="mt-3 text-[11px] font-medium text-teal group-hover:text-ink transition-colors">Перейти →</div>
            </Link>
          ))}
        </div>
      </section>

      {/* Exam prep */}
      <section className="max-w-6xl mx-auto px-6 md:px-10 mb-20 md:mb-28">
        <div className="bg-gradient-to-br from-coral-soft/30 to-parchment rounded-[2.5rem] p-8 md:p-14 border border-coral/10">
          <h2 className="font-display text-2xl md:text-3xl font-semibold text-ink mb-2">Подготовка к экзаменам</h2>
          <p className="text-sm text-ink-muted mb-8">ВПР, ОГЭ, ЕГЭ — с разбором типовых ошибок и стратегиями решения</p>
          <div className="grid sm:grid-cols-3 gap-3">
            {[
              { label: "ВПР", desc: "По каждому классу начальной и основной школы. Тренировочные варианты в соответствии с ФГОС.", href: "/exams/vpr" },
              { label: "ОГЭ", desc: "Алгебра, геометрия, теория чисел, комбинаторика. Структура экзамена и типовые ошибки.", href: "/exams/oge" },
              { label: "ЕГЭ", desc: "Профильная и базовая математика. Разбор вариантов, стратегии, подготовка к сложным заданиям.", href: "/exams/ege" },
            ].map((exam) => (
              <Link key={exam.label} href={exam.href} className="group block bg-white rounded-2xl p-6 border border-ink/5 shadow-sm hover:shadow-md transition-all hover:-translate-y-0.5">
                <h3 className="font-display text-xl font-semibold text-ink mb-2">{exam.label}</h3>
                <p className="text-xs text-ink-muted leading-relaxed mb-3">{exam.desc}</p>
                <span className="text-[11px] font-medium text-coral">Перейти →</span>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}
