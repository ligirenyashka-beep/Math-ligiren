import Link from "next/link";
import { ArrowRight, Sparkles, Compass, Mountain, Crown, BookOpen, Star, ShieldCheck, Award } from "lucide-react";

export default function HomePage() {
  return (
    <main className="min-h-screen bg-cream">
      {/* Hero — clean, spacious, one message */}
      <section className="relative overflow-hidden bg-gradient-to-b from-parchment to-cream">
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-gold-soft/30 rounded-full blur-[120px] -translate-y-1/3 translate-x-1/4" />
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-primary-soft/30 rounded-full blur-[100px] translate-y-1/2 -translate-x-1/4" />

        <div className="relative max-w-6xl mx-auto px-6 md:px-10 pt-24 md:pt-36 pb-20 md:pb-28">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-ink/5 border border-ink/5 mb-8">
              <Star className="w-3.5 h-3.5 text-gold" />
              <span className="text-xs font-medium text-ink-muted tracking-wide">Полная школьная программа + олимпиады + высшая математика</span>
            </div>

            <h1 className="font-display text-[clamp(2.8rem,7vw,5.5rem)] font-light text-ink leading-[1.05] tracking-tight mb-6">
              Математика, которая <br />
              <span className="italic font-normal text-gold">растит уверенность</span>
            </h1>

            <p className="text-base md:text-xl text-ink-muted leading-relaxed max-w-xl mb-10">
              ПингЛи Академия — это единая образовательная система от 4 до 18 лет и дальше. Без таймеров. Без страха. Только ясность, глубина и радость открытия.
            </p>

            <div className="flex flex-wrap gap-3">
              <Link href="/stages" className="inline-flex items-center gap-2 px-7 py-3.5 bg-ink text-cream rounded-2xl text-sm font-medium hover:bg-ink-soft transition-colors shadow-xl shadow-ink/10">
                Начать обучение <ArrowRight className="w-4 h-4" />
              </Link>
              <Link href="/theory" className="inline-flex items-center gap-2 px-7 py-3.5 bg-parchment text-ink rounded-2xl text-sm font-medium hover:bg-parchment/80 transition-colors border border-ink/5">
                Теория по классам
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stages — clean cards, one per row on mobile, 5 columns on desktop */}
      <section id="stages" className="max-w-6xl mx-auto px-6 md:px-10 -mt-10 md:-mt-16 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 md:gap-3">
          {[
            { code: "early", title: "4 — 7 лет", subtitle: "Начало пути", desc: "Игра, образы, звук, движение. Без текстовой нагрузки.", color: "#F0A060", bg: "bg-[#FEF5E8]", icon: Sparkles, href: "/stages/early" },
            { code: "primary", title: "8 — 11 лет", subtitle: "Фундамент", desc: "Арифметика, геометрия, текстовые задачи. Плавный переход к абстракции.", color: "#6BA8D0", bg: "bg-[#EAF4FB]", icon: Compass, href: "/stages/primary" },
            { code: "middle", title: "12 — 15 лет", subtitle: "Углубление", desc: "Алгебра, комбинаторика, теория чисел. ОГЭ и олимпиады.", color: "#7B5AA6", bg: "bg-[#F0E8F8]", icon: Mountain, href: "/stages/middle" },
            { code: "high", title: "16 — 18 лет", subtitle: "Мастерство", desc: "Анализ, аналитическая геометрия, ЕГЭ. Подготовка к вузу.", color: "#C85A5A", bg: "bg-[#FCE8E8]", icon: Crown, href: "/stages/high" },
            { code: "uni", title: "18+ лет", subtitle: "Высшая математика", desc: "Анализ, алгебра, теория вероятностей. Абитуриенты и студенты.", color: "#3D6B6B", bg: "bg-[#E8F0F0]", icon: BookOpen, href: "/stages/uni" },
          ].map((stage) => (
            <Link key={stage.code} href={stage.href} className="group relative p-6 md:p-5 rounded-3xl bg-white shadow-[0_4px_20px_rgba(16,24,40,0.06)] hover:shadow-[0_8px_30px_rgba(16,24,40,0.1)] transition-all duration-300 hover:-translate-y-1 border border-ink/5">
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-4 shadow-sm`} style={{ backgroundColor: stage.color + "15" }}>
                <stage.icon className="w-6 h-6" style={{ color: stage.color }} />
              </div>
              <h3 className="font-display text-xl font-semibold text-ink mb-1">{stage.title}</h3>
              <p className="text-xs font-medium tracking-wide uppercase mb-3" style={{ color: stage.color }}>{stage.subtitle}</p>
              <p className="text-[13px] text-ink-muted leading-relaxed">{stage.desc}</p>
              <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                <ArrowRight className="w-4 h-4 text-ink-muted" />
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Principles — minimal, 3 columns */}
      <section className="max-w-6xl mx-auto px-6 md:px-10 py-20 md:py-28">
        <div className="grid md:grid-cols-3 gap-10 md:gap-8">
          <div>
            <div className="w-10 h-10 rounded-xl bg-ink/5 flex items-center justify-center mb-5">
              <ShieldCheck className="w-5 h-5 text-ink-soft" />
            </div>
            <h3 className="font-display text-2xl font-semibold text-ink mb-3">Без таймеров</h3>
            <p className="text-sm text-ink-muted leading-relaxed">Мы не используем таймеры в практиках. Мотивация растёт от понимания, а не от страха не успеть. Каждый работает в своём ритме.</p>
          </div>
          <div>
            <div className="w-10 h-10 rounded-xl bg-ink/5 flex items-center justify-center mb-5">
              <Award className="w-5 h-5 text-ink-soft" />
            </div>
            <h3 className="font-display text-2xl font-semibold text-ink mb-3">Единая система навыков</h3>
            <p className="text-sm text-ink-muted leading-relaxed">Макронавыки и микронавыки связаны в единую карту. Вы видите, как каждый шаг ведёт к большому достижению — от счёта до высшего анализа.</p>
          </div>
          <div>
            <div className="w-10 h-10 rounded-xl bg-ink/5 flex items-center justify-center mb-5">
              <Star className="w-5 h-5 text-ink-soft" />
            </div>
            <h3 className="font-display text-2xl font-semibold text-ink mb-3">Возрастно-адаптировано</h3>
            <p className="text-sm text-ink-muted leading-relaxed">Для 4-7 лет — визуальные и аудио-подсказки, минимум текста. Для старших — глубокая теория, доказательства, олимпиадные задачи.</p>
          </div>
        </div>
      </section>

      {/* What we cover — clean list */}
      <section className="max-w-6xl mx-auto px-6 md:px-10 pb-20 md:pb-28">
        <div className="bg-gradient-to-br from-parchment to-cream rounded-[2.5rem] p-8 md:p-14 border border-ink/5 shadow-[0_4px_40px_rgba(16,24,40,0.04)]">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-10">
            <div>
              <h2 className="font-display text-3xl md:text-4xl font-semibold text-ink mb-2">Что входит в программу</h2>
              <p className="text-ink-muted text-sm md:text-base">Весь путь от дошкольника до студента в одной системе</p>
            </div>
            <Link href="/stages" className="inline-flex items-center gap-2 text-sm font-medium text-ink hover:text-gold transition-colors group">
              Посмотреть этапы <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-6">
            {[
              { label: "Дошкольное образование (4-7)", desc: "Счёт, формы, логика через игру и образы", tag: "4-7 лет" },
              { label: "Начальная школа (1-4 класс)", desc: "Арифметика, геометрия, текстовые задачи", tag: "8-11 лет" },
              { label: "Средняя школа (5-9 класс)", desc: "Алгебра, геометрия, теория чисел, ОГЭ", tag: "12-15 лет" },
              { label: "Старшая школа (10-11 класс)", desc: "Анализ, геометрия, ЕГЭ, олимпиада", tag: "16-18 лет" },
              { label: "Высшая математика", desc: "Анализ, алгебра, теория вероятностей", tag: "18+" },
              { label: "Олимпиадная математика", desc: "Международные, всероссийские, региональные", tag: "Все возраста" },
              { label: "Подготовка к ВПР", desc: "По каждому классу начальной и основной школы", tag: "1-9 класс" },
              { label: "Подготовка к ОГЭ", desc: "Профильная математика с разбором типовых ошибок", tag: "9 класс" },
              { label: "Подготовка к ЕГЭ", desc: "Профильная и базовая математика, стратегии", tag: "10-11 класс" },
            ].map((item) => (
              <div key={item.label} className="flex items-start gap-3">
                <div className="w-1.5 h-1.5 rounded-full bg-gold mt-2 shrink-0" />
                <div>
                  <h4 className="text-sm font-semibold text-ink mb-0.5">{item.label}</h4>
                  <p className="text-xs text-ink-muted leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}
