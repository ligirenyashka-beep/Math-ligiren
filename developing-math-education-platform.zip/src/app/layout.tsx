import Navigation from "@/components/Navigation";
import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "ПингЛи Академия — Математика для всех возрастов",
  description: "Единая образовательная система от 4 до 18 лет. Без таймеров. Школьная, олимпиадная и высшая математика.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru">
      <body className="bg-cream text-ink antialiased font-body">
        <Navigation />
        {children}
        <footer className="border-t border-parchment/60 bg-parchment/30">
          <div className="max-w-6xl mx-auto px-6 md:px-10 py-12 md:py-16">
            <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6">
              <div>
                <h4 className="font-display text-xl font-semibold text-ink mb-2">ПингЛи Академия</h4>
                <p className="text-xs text-ink-muted leading-relaxed max-w-md">Единая образовательная платформа от дошкольника до студента. Школьная, олимпиадная и высшая математика в одной системе.</p>
              </div>
              <div className="flex gap-6 text-xs text-ink-muted">
                <div>
                  <p className="font-medium text-ink mb-1">Этапы</p>
                  <ul className="space-y-0.5">
                    <li><a href="/stages/early" className="hover:text-ink transition-colors">4 — 7 лет</a></li>
                    <li><a href="/stages/primary" className="hover:text-ink transition-colors">8 — 11 лет</a></li>
                    <li><a href="/stages/middle" className="hover:text-ink transition-colors">12 — 15 лет</a></li>
                    <li><a href="/stages/high" className="hover:text-ink transition-colors">16 — 18 лет</a></li>
                    <li><a href="/stages/uni" className="hover:text-ink transition-colors">18+ лет</a></li>
                  </ul>
                </div>
                <div>
                  <p className="font-medium text-ink mb-1">Подготовка</p>
                  <ul className="space-y-0.5">
                    <li><a href="/exams" className="hover:text-ink transition-colors">ВПР</a></li>
                    <li><a href="/exams" className="hover:text-ink transition-colors">ОГЭ</a></li>
                    <li><a href="/exams" className="hover:text-ink transition-colors">ЕГЭ</a></li>
                  </ul>
                </div>
                <div>
                  <p className="font-medium text-ink mb-1">Разделы</p>
                  <ul className="space-y-0.5">
                    <li><a href="/theory" className="hover:text-ink transition-colors">Теория</a></li>
                    <li><a href="/practice" className="hover:text-ink transition-colors">Практика</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="mt-10 pt-6 border-t border-ink/5 text-[11px] text-ink-muted/60 flex flex-col sm:flex-row justify-between items-center gap-2">
              <span>© ПингЛи Академия. Образовательная платформа для детей, подростков и взрослых.</span>
              <span>Без таймеров. С заботой о мотивации.</span>
            </div>
          </div>
        </footer>
      </body>
    </html>
  );
}
