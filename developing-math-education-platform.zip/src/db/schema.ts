import { pgTable, serial, text, integer, boolean, timestamp, jsonb, varchar } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

// Age stages (макро-этапы)
export const stages = pgTable("stages", {
  id: serial("id").primaryKey(),
  code: varchar("code", { length: 20 }).notNull().unique(), // e.g., "early", "primary", "middle", "high", "uni"
  title: text("title").notNull(),
  subtitle: text("subtitle").notNull(),
  ageRange: text("age_range").notNull(), // "4-7 лет"
  color: varchar("color", { length: 20 }).notNull(),
  icon: varchar("icon", { length: 50 }).notNull(),
  orderIndex: integer("order_index").notNull(),
  description: text("description").notNull(),
});

export const stageRelations = relations(stages, ({ many }) => ({
  macroSkills: many(macroSkills),
}));

// Macro skills (крупные навыки)
export const macroSkills = pgTable("macro_skills", {
  id: serial("id").primaryKey(),
  stageId: integer("stage_id").references(() => stages.id).notNull(),
  title: text("title").notNull(),
  subtitle: text("subtitle").notNull(),
  icon: varchar("icon", { length: 50 }).notNull(),
  orderIndex: integer("order_index").notNull(),
  color: varchar("color", { length: 20 }).notNull(),
});

export const macroSkillRelations = relations(macroSkills, ({ one, many }) => ({
  stage: one(stages, { fields: [macroSkills.stageId], references: [stages.id] }),
  microSkills: many(microSkills),
}));

// Micro skills (детальные навыки)
export const microSkills = pgTable("micro_skills", {
  id: serial("id").primaryKey(),
  macroSkillId: integer("macro_skill_id").references(() => macroSkills.id).notNull(),
  title: text("title").notNull(),
  subtitle: text("subtitle").notNull(),
  gradeTarget: text("grade_target").notNull(), // "1 класс", "2 класс", etc.
  standard: text("standard").notNull(), // FGOS, etc.
  orderIndex: integer("order_index").notNull(),
  description: text("description").notNull(),
});

export const microSkillRelations = relations(microSkills, ({ one, many }) => ({
  macroSkill: one(macroSkills, { fields: [microSkills.macroSkillId], references: [macroSkills.id] }),
  topics: many(topics),
  practices: many(practices),
}));

// Theory topics (теория по главам)
export const topics = pgTable("topics", {
  id: serial("id").primaryKey(),
  microSkillId: integer("micro_skill_id").references(() => microSkills.id).notNull(),
  title: text("title").notNull(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  contentType: varchar("content_type", { length: 20 }).notNull(), // "text", "visual", "audio"
  body: text("body").notNull(),
  orderIndex: integer("order_index").notNull(),
  examPrep: boolean("exam_prep").default(false),
  examType: varchar("exam_type", { length: 20 }), // "OGE", "EGE", "VPR"
});

export const topicRelations = relations(topics, ({ one }) => ({
  microSkill: one(microSkills, { fields: [topics.microSkillId], references: [microSkills.id] }),
}));

// Practice tasks (практики без таймеров)
export const practices = pgTable("practices", {
  id: serial("id").primaryKey(),
  microSkillId: integer("micro_skill_id").references(() => microSkills.id).notNull(),
  title: text("title").notNull(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  difficulty: integer("difficulty").notNull(), // 1-5
  ageAppropriate: text("age_appropriate").notNull(), // "4-7", "8-11", etc.
  body: text("body").notNull(),
  imageUrl: text("image_url"),
  answer: text("answer").notNull(),
  hint: text("hint"),
  hasTimer: boolean("has_timer").default(false).notNull(),
  isVisual: boolean("is_visual").default(false).notNull(),
  isAudio: boolean("is_audio").default(false).notNull(),
  orderIndex: integer("order_index").notNull(),
});

export const practiceRelations = relations(practices, ({ one }) => ({
  microSkill: one(microSkills, { fields: [practices.microSkillId], references: [microSkills.id] }),
}));

// User progress tracking
export const userProgress = pgTable("user_progress", {
  id: serial("id").primaryKey(),
  practiceId: integer("practice_id").references(() => practices.id).notNull(),
  userId: text("user_id").notNull(), // for demo we use anonymous IDs
  completed: boolean("completed").default(false).notNull(),
  attempts: integer("attempts").default(0).notNull(),
  correct: boolean("correct").default(false),
  completedAt: timestamp("completed_at"),
});
