import { db } from "./index";
import {
  stages,
  macroSkills,
  microSkills,
  topics,
  practices,
} from "./schema";

export async function seed() {
  // Clear existing data (optional for clean seed)
  await db.delete(practices);
  await db.delete(topics);
  await db.delete(microSkills);
  await db.delete(macroSkills);
  await db.delete(stages);

  // 1. INSERT STAGES
  const stageData = [
    {
      code: "early",
      title: "Начало пути",
      subtitle: "От 4 до 7 лет",
      ageRange: "4 — 7 лет",
      color: "#E8B87D",
      icon: "Sparkles",
      orderIndex: 1,
      description:
        "Математика через игру, образы, цвета и движения. Без текста, с аудио-подсказками.",
    },
    {
      code: "primary",
      title: "Фундамент",
      subtitle: "От 8 до 11 лет",
      ageRange: "8 — 11 лет",
      color: "#6BA8D0",
      icon: "Compass",
      orderIndex: 2,
      description:
        "Основы арифметики, геометрии и логики. Плавный переход от образного к абстрактному мышлению.",
    },
    {
      code: "middle",
      title: "Углубление",
      subtitle: "От 12 до 15 лет",
      ageRange: "12 — 15 лет",
      color: "#7B5AA6",
      icon: "Mountain",
      orderIndex: 3,
      description:
        "Алгебра, геометрия, комбинаторика и начала анализа. Подготовка к ОГЭ и олимпиадам.",
    },
    {
      code: "high",
      title: "Мастерство",
      subtitle: "От 16 до 18 лет",
      ageRange: "16 — 18 лет",
      color: "#C85A5A",
      icon: "Crown",
      orderIndex: 4,
      description:
        "ЕГЭ, высшая математика, теория чисел, аналитическая геометрия, подготовка к вузам.",
    },
    {
      code: "uni",
      title: "Высшая математика",
      subtitle: "Абитуриенты и студенты",
      ageRange: "18+ лет",
      color: "#3D6B6B",
      icon: "BookOpen",
      orderIndex: 5,
      description:
        "Математический анализ, линейная алгебра, теория вероятностей, дифференциальные уравнения.",
    },
  ];

  const insertedStages = await db.insert(stages).values(stageData).returning();
  console.log("Inserted stages:", insertedStages.length);

  // 2. INSERT MACRO SKILLS
  const macroData = [
    // Early (4-7) — 4 macro-skills
    { stageId: insertedStages[0].id, title: "Число и счёт", subtitle: "От образа к цифре", icon: "Hash", orderIndex: 1, color: "#F0A060" },
    { stageId: insertedStages[0].id, title: "Форма и пространство", subtitle: "Геометрия через игру", icon: "Shapes", orderIndex: 2, color: "#D0A070" },
    { stageId: insertedStages[0].id, title: "Логика и закономерности", subtitle: "Найди правило", icon: "Lightbulb", orderIndex: 3, color: "#E8C090" },
    { stageId: insertedStages[0].id, title: "Математика в жизни", subtitle: "Деньги, время, измерения", icon: "Clock", orderIndex: 4, color: "#F0B880" },

    // Primary (8-11) — 5 macro-skills
    { stageId: insertedStages[1].id, title: "Арифметика", subtitle: "Числа и действия", icon: "Calculator", orderIndex: 1, color: "#6BA8D0" },
    { stageId: insertedStages[1].id, title: "Геометрия", subtitle: "Плоскость и фигуры", icon: "Triangle", orderIndex: 2, color: "#7BB0D8" },
    { stageId: insertedStages[1].id, title: "Текстовые задачи", subtitle: "Чтение и решение", icon: "BookText", orderIndex: 3, color: "#8BC2E0" },
    { stageId: insertedStages[1].id, title: "Комбинаторика", subtitle: "Перебор и подсчёт", icon: "Grid3x3", orderIndex: 4, color: "#9AD2E8" },
    { stageId: insertedStages[1].id, title: "Логика", subtitle: "Доказательства и рассуждения", icon: "Brain", orderIndex: 5, color: "#A8DEF0" },

    // Middle (12-15) — 6 macro-skills
    { stageId: insertedStages[2].id, title: "Алгебра", subtitle: "Уравнения и функции", icon: "FunctionSquare", orderIndex: 1, color: "#7B5AA6" },
    { stageId: insertedStages[2].id, title: "Геометрия", subtitle: "Треугольники и окружности", icon: "CircleDot", orderIndex: 2, color: "#8B6AB8" },
    { stageId: insertedStages[2].id, title: "Комбинаторика и вероятность", subtitle: "Олимпиадные задачи", icon: "Dices", orderIndex: 3, color: "#9B7ACA" },
    { stageId: insertedStages[2].id, title: "Теория чисел", subtitle: "Делимость, НОД, НОК", icon: "Hash", orderIndex: 4, color: "#AB8ADC" },
    { stageId: insertedStages[2].id, title: "Логика и доказательства", subtitle: "Методы решения", icon: "Lightbulb", orderIndex: 5, color: "#BB9AEE" },
    { stageId: insertedStages[2].id, title: "Подготовка к ОГЭ", subtitle: "Структура экзамена", icon: "Award", orderIndex: 6, color: "#CBBAF0" },

    // High (16-18) — 6 macro-skills
    { stageId: insertedStages[3].id, title: "Алгебра и анализ", subtitle: "Производные и интегралы", icon: "TrendingUp", orderIndex: 1, color: "#C85A5A" },
    { stageId: insertedStages[3].id, title: "Аналитическая геометрия", subtitle: "Плоскость и пространство", icon: "Compass", orderIndex: 2, color: "#D07070" },
    { stageId: insertedStages[3].id, title: "Комбинаторика", subtitle: "Перестановки, сочетания", icon: "Grid3x3", orderIndex: 3, color: "#D88080" },
    { stageId: insertedStages[3].id, title: "Теория чисел", subtitle: "Конгруэнции, теоремы", icon: "Hash", orderIndex: 4, color: "#E09090" },
    { stageId: insertedStages[3].id, title: "Подготовка к ЕГЭ", subtitle: "Все профили", icon: "Award", orderIndex: 5, color: "#E0A0A0" },
    { stageId: insertedStages[3].id, title: "Олимпиадная математика", subtitle: "Сложные задачи", icon: "Crown", orderIndex: 6, color: "#F0B0B0" },

    // Uni (18+) — 5 macro-skills
    { stageId: insertedStages[4].id, title: "Математический анализ", subtitle: "Пределы, производные, интегралы", icon: "BookOpen", orderIndex: 1, color: "#3D6B6B" },
    { stageId: insertedStages[4].id, title: "Линейная алгебра", subtitle: "Матрицы и векторные пространства", icon: "Grid3x3", orderIndex: 2, color: "#4D7B7B" },
    { stageId: insertedStages[4].id, title: "Теория вероятностей", subtitle: "Случайные величины", icon: "Dices", orderIndex: 3, color: "#5D8B8B" },
    { stageId: insertedStages[4].id, title: "Дифференциальные уравнения", subtitle: "Обыкновенные и в частных производных", icon: "Waves", orderIndex: 4, color: "#6D9B9B" },
    { stageId: insertedStages[4].id, title: "Абитуриентская подготовка", subtitle: "Математика для вузов", icon: "Award", orderIndex: 5, color: "#7DABAB" },
  ];

  const insertedMacros = await db.insert(macroSkills).values(macroData).returning();
  console.log("Inserted macro skills:", insertedMacros.length);

  // 3. INSERT MICRO SKILLS + TOPICS + PRACTICES
  // We'll generate for all stages with representative content
  const microData: any[] = [];
  const topicData: any[] = [];
  const practiceData: any[] = [];

  // Early stage: 4-7 years — no text-heavy, visual and audio
  const earlyMacro = insertedMacros.filter(m => m.stageId === insertedStages[0].id);
  const earlyMicroNames = [
    ["Счёт до 10", "Образы чисел", "Сложение через картинки", "Вычитание в жизни", "Порядок чисел"],
    ["Круг, квадрат, треугольник", "Большое и маленькое", "Цвета и формы", "Построение из палочек", "Пространственные отношения"],
    ["Найди пару", "Продолжи ряд", "Что лишнее", "Найди правило", "Математика в сказках"],
    ["Деньги в игре", "Сколько времени?", "Измеряем рост", "Вес и объём", "Математика в магазине"],
  ];

  for (let i = 0; i < earlyMacro.length; i++) {
    const macro = earlyMacro[i];
    const micros = earlyMicroNames[i];
    for (let j = 0; j < micros.length; j++) {
      const mTitle = micros[j];
      const slugBase = mTitle.toLowerCase().replace(/[^a-zа-яё0-9]/gi, "-").replace(/-+/g, "-").slice(0, 60);
      const grade = ["Дошкольник", "1 класс", "2 класс", "3 класс", "4 класс"][j % 5] || "Дошкольник";
      microData.push({
        macroSkillId: macro.id,
        title: mTitle,
        subtitle: `Для детей 4-7 лет`,
        gradeTarget: grade,
        standard: "ФГОС ДО и начальная школа",
        orderIndex: j + 1,
        description: `Возрастной подход без текстовой нагрузки. Визуальные и аудио-материалы.`
      });
    }
  }

  // Primary stage: 8-11 years
  const primaryMacro = insertedMacros.filter(m => m.stageId === insertedStages[1].id);
  const primaryTopics: Record<string, string[]> = {
    "Арифметика": ["Натуральные числа", "Сложение и вычитание", "Умножение и деление", "Дроби", "Десятичные дроби"],
    "Геометрия": ["Плоскость и прямая", "Углы", "Треугольники", "Четырёхугольники", "Окружность"],
    "Текстовые задачи": ["Задачи на движение", "Задачи на работу", "Проценты", "Пропорции", "Комбинированные задачи"],
    "Комбинаторика": ["Правило суммы", "Правило произведения", "Перестановки", "Сочетания", "Олимпиадные задачи"],
    "Логика": ["Истинность высказываний", "Доказательство", "Метод от противного", "Индукция", "Графы"],
  };
  for (let i = 0; i < primaryMacro.length; i++) {
    const macro = primaryMacro[i];
    const topicsList = primaryTopics[macro.title] || ["Теория", "Практика", "Олимпиада", "Экзамен"];
    for (let j = 0; j < topicsList.length; j++) {
      const tTitle = topicsList[j];
      microData.push({
        macroSkillId: macro.id,
        title: tTitle,
        subtitle: `Класс ${j + 2} — ${j + 3}`,
        gradeTarget: `${j + 2} — ${j + 3} класс`,
        standard: "ФГОС начальное общее образование",
        orderIndex: j + 1,
        description: `Полное соответствие школьной программе. Подготовка к ВПР и олимпиадам.`
      });
    }
  }

  // Middle stage: 12-15 years
  const middleMacro = insertedMacros.filter(m => m.stageId === insertedStages[2].id);
  const middleTopics: Record<string, string[]> = {
    "Алгебра": ["Линейные уравнения", "Квадратные уравнения", "Системы уравнений", "Неравенства", "Функции и графики", "Прогрессии"],
    "Геометрия": ["Треугольники", "Окружности", "Четырёхугольники", "Площадь", "Теорема Пифагора", "Тригонометрия"],
    "Комбинаторика и вероятность": ["Перестановки", "Сочетания", "Вероятность", "Условная вероятность", "Олимпиадные задачи"],
    "Теория чисел": ["Делимость", "Простые числа", "НОД и НОК", "Конгруэнции", "Теоремы Ферма и Эйлера"],
    "Логика и доказательства": ["Прямое доказательство", "От противного", "Математическая индукция", "Графы и сети"],
    "Подготовка к ОГЭ": ["Структура ОГЭ", "Алгебра на ОГЭ", "Геометрия на ОГЭ", "Практические задания", "Разбор типовых ошибок"],
  };
  for (let i = 0; i < middleMacro.length; i++) {
    const macro = middleMacro[i];
    const topicsList = middleTopics[macro.title] || ["Теория", "Практика", "Олимпиада"];
    for (let j = 0; j < topicsList.length; j++) {
      const tTitle = topicsList[j];
      microData.push({
        macroSkillId: macro.id,
        title: tTitle,
        subtitle: j < 4 ? `7 — 9 класс` : `Подготовка к экзамену`,
        gradeTarget: j < 4 ? `7 — 9 класс` : `9 класс`,
        standard: j < 4 ? "ФГОС основное общее образование" : "ФГОС ОГЭ",
        orderIndex: j + 1,
        description: `Комплексная программа для средней школы. От теории до экзамена.`
      });
    }
  }

  // High stage: 16-18 years
  const highMacro = insertedMacros.filter(m => m.stageId === insertedStages[3].id);
  const highTopics: Record<string, string[]> = {
    "Алгебра и анализ": ["Пределы", "Производные", "Интегралы", "Экстремумы", "Исследование функций", "Ряды"],
    "Аналитическая геометрия": ["Прямая на плоскости", "Окружность", "Эллипс и гипербола", "Плоскость в пространстве", "Поверхности второго порядка"],
    "Комбинаторика": ["Перестановки с повторениями", "Сочетания с повторениями", "Биномиальная теорема", "Принцип включения-исключения"],
    "Теория чисел": ["Теорема Вильсона", "Малая теорема Ферма", "Теорема Эйлера", "Китайская теорема об остатках", "Диофантовы уравнения"],
    "Подготовка к ЕГЭ": ["Профильная математика", "Базовая математика", "Стратегия экзамена", "Типовые ошибки", "Разбор вариантов"],
    "Олимпиадная математика": ["Комбинаторика", "Теория чисел", "Алгебра", "Геометрия", "Логика и доказательства", "Международные олимпиады"],
  };
  for (let i = 0; i < highMacro.length; i++) {
    const macro = highMacro[i];
    const topicsList = highTopics[macro.title] || ["Теория", "Практика", "Экзамен"];
    for (let j = 0; j < topicsList.length; j++) {
      const tTitle = topicsList[j];
      microData.push({
        macroSkillId: macro.id,
        title: tTitle,
        subtitle: j < 4 ? `10 — 11 класс` : `Подготовка`,
        gradeTarget: j < 4 ? `10 — 11 класс` : `11 класс`,
        standard: j < 4 ? "ФГОС среднее общее образование" : "ФГОС ЕГЭ",
        orderIndex: j + 1,
        description: `Полная подготовка к ЕГЭ и олимпиадам. Глубокая теория + интенсивная практика.`
      });
    }
  }

  // Uni stage: 18+ years
  const uniMacro = insertedMacros.filter(m => m.stageId === insertedStages[4].id);
  const uniTopics: Record<string, string[]> = {
    "Математический анализ": ["Пределы последовательностей", "Производная функции", "Неопределённый интеграл", "Определённый интеграл", "Несобственные интегралы", "Ряды"],
    "Линейная алгебра": ["Матрицы и определители", "Системы линейных уравнений", "Векторные пространства", "Линейные операторы", "Квадратичные формы"],
    "Теория вероятностей": ["События и операции", "Классическое определение", "Условная вероятность", "Случайные величины", "Закон больших чисел", "Центральная предельная теорема"],
    "Дифференциальные уравнения": ["ДУ первого порядка", "ДУ высших порядков", "Системы ДУ", "ДУ в частных производных", "Методы решения"],
    "Абитуриентская подготовка": ["Математика для технических вузов", "Математика для экономических вузов", "Олимпиадная подготовка", "Научные исследования"]
  };
  for (let i = 0; i < uniMacro.length; i++) {
    const macro = uniMacro[i];
    const topicsList = uniTopics[macro.title] || ["Теория", "Практика", "Исследование"];
    for (let j = 0; j < topicsList.length; j++) {
      const tTitle = topicsList[j];
      microData.push({
        macroSkillId: macro.id,
        title: tTitle,
        subtitle: j < 3 ? `1 — 2 курс` : `Абитуриент`,
        gradeTarget: j < 3 ? `1 — 2 курс` : `Абитуриент`,
        standard: "Высшее математическое образование",
        orderIndex: j + 1,
        description: `Программа высшей математики в соответствии с федеральными образовательными стандартами высшего образования.`
      });
    }
  }

  const insertedMicros = await db.insert(microSkills).values(microData).returning();
  console.log("Inserted micro skills:", insertedMicros.length);

  // 4. INSERT TOPICS
  for (const micro of insertedMicros) {
    const topicNames = [
      "Введение и основные понятия",
      "Основные теоремы",
      "Методы решения",
      "Практические примеры",
      "Олимпиадные задачи и разбор",
      "Подготовка к экзамену"
    ];
    for (let t = 0; t < 3; t++) {
      const title = topicNames[t] || `Тема ${t + 1}`;
      const slug = `${micro.title}-${title}`.toLowerCase().replace(/[^a-zа-яё0-9]/gi, "-").replace(/-+/g, "-").slice(0, 90);
      const examPrep = t >= 4;
      topicData.push({
        microSkillId: micro.id,
        title,
        slug: slug + `-${micro.id}-${t}`,
        contentType: t === 0 ? "visual" : t === 1 ? "text" : "audio",
        body: `<h2>${title}</h2><p>Это подробная теория по теме «${micro.title}». Содержит объяснения, примеры, доказательства и визуальные материалы.</p><p>Для детей младшего возраста (4-7 лет) используются только картинки, голосовые подсказки и интерактивные элементы — без сложных текстов.</p>`,
        orderIndex: t + 1,
        examPrep,
        examType: examPrep ? (micro.gradeTarget.includes("9") ? "OGE" : micro.gradeTarget.includes("11") ? "EGE" : micro.gradeTarget.includes("класс") ? "VPR" : null) : null,
      });
    }
  }
  await db.insert(topics).values(topicData);
  console.log("Inserted topics:", topicData.length);

  // 5. INSERT PRACTICES (NO TIMERS EVER)
  // Create age-appropriate practices
  const practiceTemplates = [
    // Early — visual/audio only, no text reading required
    { title: "Найди одинаковые фигуры", body: "Посмотри на картинки. Какие две фигуры одинаковые? Выбери их пальцем.", imageUrl: "", answer: "2 и 4", hint: "Посмотри на цвет и форму.", difficulty: 1, isVisual: true, isAudio: true, hasTimer: false },
    { title: "Сколько яблок?", body: "Посмотри на картинку. Сколько яблок в корзине? Нажми правильную цифру.", imageUrl: "", answer: "5", hint: "Считай каждое яблоко пальчиком.", difficulty: 1, isVisual: true, isAudio: true, hasTimer: false },
    { title: "Большое или маленькое?", body: "Посмотри на предметы. Какой из них самый большой? Нажми на него.", imageUrl: "", answer: "Мяч", hint: "Мяч больше всех!", difficulty: 1, isVisual: true, isAudio: true, hasTimer: false },
    { title: "Продолжи ряд", body: "Красный, синий, красный, синий... Какой цвет будет следующим?", imageUrl: "", answer: "Красный", hint: "Посмотри на повторение цветов.", difficulty: 2, isVisual: true, isAudio: true, hasTimer: false },
    { title: "Посчитай кружки", body: "Сколько кружков на картинке? Нажми цифру.", imageUrl: "", answer: "3", hint: "Один, два, три!", difficulty: 1, isVisual: true, isAudio: true, hasTimer: false },
    { title: "Где квадрат?", body: "Посмотри на фигуры. Найди квадрат. Нажми на него.", imageUrl: "", answer: "Вторая фигура", hint: "У квадрата все стороны равны.", difficulty: 1, isVisual: true, isAudio: true, hasTimer: false },
    { title: "Что лишнее?", body: "Посмотри на предметы. Какой из них не подходит к остальным?", imageUrl: "", answer: "Яблоко", hint: "Остальные — это игрушки.", difficulty: 2, isVisual: true, isAudio: true, hasTimer: false },
    { title: "Найди тень", body: "Посмотри на предмет. Какая тень ему подходит? Нажми на правильную тень.", imageUrl: "", answer: "Первая тень", hint: "Посмотри на форму предмета сверху.", difficulty: 2, isVisual: true, isAudio: true, hasTimer: false },
    { title: "Посчитай монеты", body: "Сколько монет на столе? Нажми правильное число.", imageUrl: "", answer: "4", hint: "Одна монета, две монеты, три...", difficulty: 1, isVisual: true, isAudio: true, hasTimer: false },
    { title: "Что идёт после?", body: "Круг, квадрат, круг, квадрат... Какой будет следующий?", imageUrl: "", answer: "Круг", hint: "Посмотри на чередование.", difficulty: 2, isVisual: true, isAudio: true, hasTimer: false },
    // Primary — simple text, visual helpers
    { title: "Сложение 5 + 3", body: "Сколько будет 5 яблок плюс 3 яблока? Посчитай и напиши ответ.", imageUrl: "", answer: "8", hint: "Считай по порядку: 6, 7, 8.", difficulty: 1, isVisual: false, isAudio: false, hasTimer: false },
    { title: "Вычитание 9 - 4", body: "У тебя было 9 конфет. Ты съел 4. Сколько осталось?", imageUrl: "", answer: "5", hint: "Считай назад: 9, 8, 7, 6, 5.", difficulty: 1, isVisual: false, isAudio: false, hasTimer: false },
    { title: "Умножение 3 × 4", body: "В коробке 3 ряда по 4 яблока в каждом. Сколько всего яблок?", imageUrl: "", answer: "12", hint: "3 + 3 + 3 + 3 = 12", difficulty: 2, isVisual: false, isAudio: false, hasTimer: false },
    { title: "Дробь: половина", body: "Пирог разрезали на 2 части. Ты взял одну. Какая это часть?", imageUrl: "", answer: "1/2", hint: "Это половина пирога.", difficulty: 2, isVisual: false, isAudio: false, hasTimer: false },
    { title: "Задача на скорость", body: "Машина едет 60 км/ч. За 2 часа сколько она проедет?", imageUrl: "", answer: "120 км", hint: "60 × 2 = 120", difficulty: 2, isVisual: false, isAudio: false, hasTimer: false },
    { title: "Периметр квадрата", body: "Сторона квадрата 5 см. Какой периметр?", imageUrl: "", answer: "20 см", hint: "4 × 5 = 20", difficulty: 2, isVisual: false, isAudio: false, hasTimer: false },
    { title: "Процент от числа", body: "Найди 10% от 50. Как это сделать?", imageUrl: "", answer: "5", hint: "10% = 1/10. 50 / 10 = 5.", difficulty: 3, isVisual: false, isAudio: false, hasTimer: false },
    { title: "Комбинаторика: выбор", body: "Есть 3 яблока и 2 груши. Сколько способов выбрать один фрукт?", imageUrl: "", answer: "5", hint: "3 яблока + 2 груши = 5 способов.", difficulty: 2, isVisual: false, isAudio: false, hasTimer: false },
    // Middle — full text, complex
    { title: "Квадратное уравнение", body: "Реши: x² - 5x + 6 = 0. Найди корни.", imageUrl: "", answer: "x = 2, x = 3", hint: "Используй теорему Виета или дискриминант: D = 25 - 24 = 1.", difficulty: 3, isVisual: false, isAudio: false, hasTimer: false },
    { title: "Теорема Пифагора", body: "В прямоугольном треугольнике катеты 3 и 4. Найди гипотенузу.", imageUrl: "", answer: "5", hint: "3² + 4² = 9 + 16 = 25. √25 = 5.", difficulty: 2, isVisual: false, isAudio: false, hasTimer: false },
    { title: "Вероятность события", body: "Бросаем кубик. Какова вероятность выпадения чётного числа?", imageUrl: "", answer: "1/2", hint: "Чётные числа: 2, 4, 6 — это 3 из 6.", difficulty: 3, isVisual: false, isAudio: false, hasTimer: false },
    { title: "НОД и НОК", body: "Найди НОД(48, 18) и НОК(48, 18).", imageUrl: "", answer: "НОД = 6, НОК = 144", hint: "48 = 2⁴ × 3, 18 = 2 × 3². НОД = 2¹ × 3¹ = 6.", difficulty: 3, isVisual: false, isAudio: false, hasTimer: false },
    { title: "Подготовка к ОГЭ: алгебра", body: "Найди значение выражения (2x - 3)(2x + 3) - 4x² при x = 1.", imageUrl: "", answer: "-9", hint: "(a-b)(a+b) = a² - b². 4 - 9 = -9 - 4 = -9? Подожди... (4-3)(4+3) - 4 = 7 - 4 = 3... Давай пересчитаем: (2-3)(2+3) - 4 = (-1)(5) - 4 = -5 - 4 = -9.", difficulty: 4, isVisual: false, isAudio: false, hasTimer: false },
    // High — EGE, olympiad
    { title: "Производная функции", body: "Найди производную f(x) = x³ - 3x² + 2x - 1.", imageUrl: "", answer: "f'(x) = 3x² - 6x + 2", hint: "Применяй правило: (xⁿ)' = n·xⁿ⁻¹.", difficulty: 3, isVisual: false, isAudio: false, hasTimer: false },
    { title: "Интеграл", body: "Вычисли ∫(2x + 3) dx от 0 до 2.", imageUrl: "", answer: "10", hint: "Первообразная: x² + 3x. F(2) - F(0) = (4 + 6) - 0 = 10.", difficulty: 3, isVisual: false, isAudio: false, hasTimer: false },
    { title: "Комбинаторика: сочетания", body: "Сколько способов выбрать 3 учеников из 10 для участия в олимпиаде?", imageUrl: "", answer: "120", hint: "C(10,3) = 10! / (3!·7!) = 120.", difficulty: 4, isVisual: false, isAudio: false, hasTimer: false },
    { title: "Теория чисел: Ферма", body: "Найди остаток от деления 2⁷ на 7 по малой теореме Ферма.", imageUrl: "", answer: "2", hint: "2⁶ ≡ 1 (mod 7). Значит 2⁷ ≡ 2.", difficulty: 4, isVisual: false, isAudio: false, hasTimer: false },
    { title: "Подготовка к ЕГЭ: профиль", body: "Найди наибольшее значение функции f(x) = x³ - 9x² + 24x - 1 на отрезке [0; 3].", imageUrl: "", answer: "19", hint: "f'(x) = 3x² - 18x + 24 = 3(x-2)(x-4). Критические точки: x=2, x=4 (вне отрезка). f(0)=-1, f(2)=19, f(3)=17. Максимум 19.", difficulty: 5, isVisual: false, isAudio: false, hasTimer: false },
  ];

  for (const practiceTemplate of practiceTemplates) {
    practiceData.push({
      microSkillId: insertedMicros[Math.floor(Math.random() * insertedMicros.length)].id,
      title: practiceTemplate.title,
      slug: practiceTemplate.title.toLowerCase().replace(/[^a-zа-яё0-9]/gi, "-").slice(0, 80) + `-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      difficulty: practiceTemplate.difficulty,
      ageAppropriate: practiceTemplate.isVisual ? "4-7" : practiceTemplate.difficulty <= 2 ? "8-11" : practiceTemplate.difficulty <= 3 ? "12-15" : "16-18",
      body: practiceTemplate.body,
      imageUrl: practiceTemplate.imageUrl,
      answer: practiceTemplate.answer,
      hint: practiceTemplate.hint,
      hasTimer: false,
      isVisual: practiceTemplate.isVisual,
      isAudio: practiceTemplate.isAudio,
      orderIndex: Math.floor(Math.random() * 10) + 1,
    });
  }
  // Deduplicate slugs
  const slugSet = new Set();
  const uniquePracticeData = practiceData.filter(p => {
    if (slugSet.has(p.slug)) return false;
    slugSet.add(p.slug);
    return true;
  });
  await db.insert(practices).values(uniquePracticeData);
  console.log("Inserted practices:", uniquePracticeData.length);
}

seed().catch(err => {
  console.error("Seed error:", err);
  process.exit(1);
});
